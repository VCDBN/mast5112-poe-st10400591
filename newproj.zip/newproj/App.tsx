import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';

// Define interface for book
interface Book {
  title: string;
  author: string;
  pages: number;
  genre: string;
}

// Predefined list of genres
const genres = [
  'Fiction',
  'Non-Fiction',
  'Fantasy',
  'Horror',
  'Adventure',
  'Sports',
  'Biography',
  'Mystery',
  'Crime',
  'Other',
];

const App = () => {
  // State to store books
  const [books, setBooks] = useState<Book[]>([]);
  // State to store form input
  const [newBook, setNewBook] = useState<Book>({
    title: '',
    author: '',
    pages: 0,
    genre: '',
  });

  // Function to add a new book
  const addBook = () => {
    setBooks([...books, newBook]);
    setNewBook({ title: '', author: '', pages: 0, genre: '' });
  };

  // Function to display the details of the last book entered
  const lastBookDetails = books.length > 0 ? books[books.length - 1] : null;

  // Function to calculate total number of pages across all books
  const totalPages = books.reduce((acc, book) => acc + book.pages, 0);

  // Function to calculate average number of pages across all books
  const averagePages = books.length > 0 ? totalPages / books.length : 0;

  // Function to display total number of books entered in each genre
  const genreCounts: { [key: string]: number } = {};
  books.forEach(book => {
    genreCounts[book.genre] = (genreCounts[book.genre] || 0) + 1;
  });

  return (
    <View>
      {/* Home Section */}
      <View style={styles.home}>
      <Text style={styles.titles}>Home</Text>
        <Text>Last Book Entered:</Text>
        {lastBookDetails && (
          <Text>
            Title: {lastBookDetails.title}, Author: {lastBookDetails.author}, Pages: {lastBookDetails.pages}, Genre: {lastBookDetails.genre}
          </Text>
        )}
        <Text>Total Number of Pages: {totalPages}</Text>
        <Text>Average Number of Pages: {averagePages}</Text>
      </View>

      {/* AddBooks Section */}
      <View style={styles.add}>
      <Text style={styles.titles}>Add Books</Text>
        <TextInput
          placeholder="Book Title"
          value={newBook.title}
          onChangeText={text => setNewBook({ ...newBook, title: text })}
        />
        <TextInput
          placeholder="Book Author"
          value={newBook.author}
          onChangeText={text => setNewBook({ ...newBook, author: text })}
        />
        <TextInput
          placeholder="Number of Pages"
          keyboardType="numeric"
          value={newBook.pages.toString()}
          onChangeText={text => setNewBook({ ...newBook, pages: parseInt(text) })}
        />
        <Picker
          selectedValue={newBook.genre}
          onValueChange={itemValue => setNewBook({ ...newBook, genre: itemValue })}
        >
          {genres.map(genre => (
            <Picker.Item key={genre} label={genre} value={genre} />
          ))}
        </Picker>
        <Button title="Add Book" onPress={addBook} />
      </View>

      {/* Genre Section */}
      <View style={styles.genre}>
      <Text style={styles.titles}>Genres</Text>
        {genres.map(genre => (
          <Text key={genre}>
            {genre}: {genreCounts[genre] || 0}
          </Text>
        ))}
      </View>

      {/* History Section */}
      <View style={styles.history}>
      <Text style={styles.titles}>History</Text>
        <Text>Last 3 Books Entered:</Text>
        {books.slice(-3).map((book, index) => (
          <Text key={index}>
            {book.title}, {book.author}, {book.pages}, {book.genre}
          </Text>
        ))}
      </View>
    </View>
  );
};

// Define StyleSheet (styles for the component)
const styles = StyleSheet.create({
  home: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20
  },

  add: {
    marginBottom: 20
  },

  genre: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20
  },

  history: {
    justifyContent: 'center',
    alignItems: 'center',
  },

  titles: {
    fontSize: 24
  
  },
});


export default App;
