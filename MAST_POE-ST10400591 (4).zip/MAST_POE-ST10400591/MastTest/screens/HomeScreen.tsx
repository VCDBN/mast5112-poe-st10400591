import React from 'react';
import { View, Text, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StackNavigationProp } from '@react-navigation/stack';

import AddBookScreen from './AddBookScreen';
import HistoryScreen from './HistoryScreen';
import GenreScreen from './GenreScreen';


type RootStackParamList = {
  Home: {
    lastBook: string;
    setLastBook: string;
    totalPages: string;
    setTotalPages: string;
    averagePages: string;
    setAveragePages: string;
    bookData: string;
    setBookData: string;
    name: "Book App"
  };
  AddBook: {
    pages: string;
    setPages: string;
    author: string;
    setAuthor: string;
    genre: string;
    setGenre: string;
    title: string;
    setTitle: string;
  };
  GenreScreen: undefined;
  HistoryScreen: undefined;
};

type AddBookScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Home'>;

type Props = {
  navigation: AddBookScreenNavigationProp;
};

function Home({ navigation }: Props) {
  return (
    <View>
      name: 
      <Text>Home Screen</Text>
      <Button
        title="Go to Add Book"
        onPress={() =>
          navigation.navigate('AddBook', {
            name: "Book App" 
          })
        }
      />
      <Button title="Go to History" onPress={() => navigation.navigate('HistoryScreen')} />
      <Button title="Go to Genre" onPress={() => navigation.navigate('GenreScreen')} />
    </View>
  );
}

export default Home;


