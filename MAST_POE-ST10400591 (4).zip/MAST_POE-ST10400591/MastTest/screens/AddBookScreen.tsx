import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import App from './HistoryScreen';







export default App;
