import React from 'react';
import { View, StyleSheet, SafeAreaView, Text} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { TextInput } from 'react-native-gesture-handler';
import 'react-native-gesture-handler';

import HomeScreen from './screens/HomeScreen';
import HistoryScreen from './screens/HistoryScreen';
import GenreScreen from './screens/GenreScreen';
import AddBookScreen from './screens/AddBookScreen';


const Tab = createBottomTabNavigator();

const App = () =>{
return(
  <SafeAreaView style={styles.safe}>
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="AddBookScreen" component={AddBookScreen}/>
        <Tab.Screen name="HomeScreen" component={HomeScreen}/>
        <Tab.Screen name="HistoryScreen" component={HistoryScreen}/>
        <Tab.Screen name="GenreScreen" component={GenreScreen}/>
      </Tab.Navigator>
    </NavigationContainer>
  </SafeAreaView>
);
};

const styles = StyleSheet.create({
  safe: {
    flex: 1
  }
})

export default App;
